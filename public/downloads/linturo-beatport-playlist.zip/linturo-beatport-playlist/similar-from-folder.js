const SIMILAR_TARGET = 100;
const MAX_SEEDS = 24;

async function similarFromFolder(seeds, { api, sleep, onProgress = () => {}, folderName = "" } = {}) {
  const incoming = (seeds || [])
    .map(normalizeSeed)
    .filter((seed) => seed.title)
    .slice(0, MAX_SEEDS);

  if (!incoming.length) {
    throw new Error("No usable song names in that folder. Use files named like Artist - Title.mp3.");
  }

  const matched = [];
  const unmatched = [];
  const seedIds = new Set();

  for (let i = 0; i < incoming.length; i += 1) {
    const item = incoming[i];
    onProgress({
      phase: "match",
      done: i,
      total: incoming.length + SIMILAR_TARGET,
      label: `Matching seed ${i + 1}/${incoming.length}: ${item.title}`,
    });

    try {
      const hit = await matchBeatportTrack(item, api);
      if (hit && !seedIds.has(hit.id)) {
        const detail = await loadTrackDetail(hit.id, api, hit);
        seedIds.add(detail.id);
        matched.push(detail);
      } else if (!hit) {
        unmatched.push(item);
      }
    } catch {
      unmatched.push(item);
    }

    await sleep(110);
  }

  if (!matched.length) {
    throw new Error("None of those files matched Beatport. Try Artist - Title filenames.");
  }

  const buckets = matched.map(() => []);
  const seen = new Set(seedIds);

  for (let i = 0; i < matched.length; i += 1) {
    const seed = matched[i];
    onProgress({
      phase: "similar",
      done: incoming.length + Math.round((i / matched.length) * 40),
      total: incoming.length + SIMILAR_TARGET,
      label: `Finding similar to ${seed.title}…`,
    });

    const related = await collectSimilarForSeed(seed, api, sleep);
    for (const track of related) {
      if (!track || seen.has(track.id)) {
        continue;
      }
      buckets[i].push({
        ...track,
        score: scoreSimilar(seed, track),
      });
    }
    buckets[i].sort((a, b) => b.score - a.score);
  }

  const similar = pickRoundRobin(buckets, SIMILAR_TARGET, seen);

  if (similar.length < SIMILAR_TARGET) {
    onProgress({
      phase: "fill",
      done: incoming.length + 50,
      total: incoming.length + SIMILAR_TARGET,
      label: "Filling from genre charts…",
    });
    const extras = await fillFromGenres(matched, api, sleep, seen, SIMILAR_TARGET - similar.length);
    similar.push(...extras);
  }

  onProgress({
    phase: "done",
    done: incoming.length + similar.length,
    total: incoming.length + SIMILAR_TARGET,
    label: `Found ${similar.length} similar tracks`,
  });

  if (!similar.length) {
    throw new Error("Matched your files, but Beatport did not return similar tracks.");
  }

  const crate = String(folderName || "").trim() || "crate";
  return {
    title: crate,
    playlistName: `${crate} · similar`.slice(0, 64),
    seeds: matched,
    unmatched,
    similar: similar.slice(0, SIMILAR_TARGET),
    totalSeeds: incoming.length,
  };
}

function normalizeSeed(seed) {
  return {
    title: String(seed?.title || "").trim(),
    artists: String(seed?.artists || "").trim(),
    file: String(seed?.file || "").trim(),
  };
}

async function matchBeatportTrack(source, api) {
  const query = `${source.artists || ""} ${source.title || ""}`.replace(/\s+/g, " ").trim().slice(0, 90);
  if (!query) {
    return null;
  }

  const data = await api("/catalog/search/", {
    query: { q: query, type: "tracks", per_page: 10, page: 1 },
  });
  const results = extractSearchTracks(data).map(normalizeImportedTrack).filter(Boolean);
  return pickMatch(source, results);
}

async function loadTrackDetail(id, api, fallback) {
  try {
    const data = await api(`/catalog/tracks/${id}/`);
    return enrichTrack(normalizeImportedTrack(data) || fallback, data);
  } catch {
    return enrichTrack(fallback, fallback);
  }
}

async function collectSimilarForSeed(seed, api, sleep) {
  const collected = [];

  for (const path of [
    `/catalog/tracks/${seed.id}/related/`,
    `/catalog/tracks/${seed.id}/similar/`,
    `/catalog/tracks/${seed.id}/recommendations/`,
  ]) {
    const batch = await tryList(api, path, { per_page: 50 });
    if (batch.length) {
      collected.push(...batch.map((item) => enrichTrack(normalizeImportedTrack(item), item)).filter(Boolean));
      break;
    }
  }

  for (const artistId of (seed.artistIds || []).slice(0, 2)) {
    collected.push(
      ...(await tryList(api, "/catalog/tracks/", {
        artist_id: artistId,
        per_page: 50,
        page: 1,
        order_by: "-publish_date",
      })).map((item) => enrichTrack(normalizeImportedTrack(item), item)).filter(Boolean)
    );
    await sleep(80);
  }

  if (seed.genreId) {
    const genreQuery = {
      genre_id: seed.genreId,
      per_page: 50,
      page: 1,
      order_by: "-publish_date",
    };
    if (Number.isFinite(seed.bpm) && seed.bpm > 0) {
      genreQuery.bpm_low = Math.max(1, Math.round(seed.bpm) - 8);
      genreQuery.bpm_high = Math.round(seed.bpm) + 8;
    }
    let genreTracks = await tryList(api, "/catalog/tracks/", genreQuery);
    if (!genreTracks.length && genreQuery.bpm_low) {
      delete genreQuery.bpm_low;
      delete genreQuery.bpm_high;
      genreTracks = await tryList(api, "/catalog/tracks/", genreQuery);
    }
    collected.push(...genreTracks.map((item) => enrichTrack(normalizeImportedTrack(item), item)).filter(Boolean));
    await sleep(80);
  }

  return collected;
}

async function fillFromGenres(seeds, api, sleep, seen, needed) {
  const out = [];
  const genreIds = [...new Set(seeds.map((seed) => seed.genreId).filter(Boolean))];
  for (const genreId of genreIds) {
    if (out.length >= needed) {
      break;
    }
    const top = await tryList(api, `/catalog/tracks/top/${genreId}/`, { per_page: 100 });
    for (const item of top) {
      const track = enrichTrack(normalizeImportedTrack(item), item);
      if (!track || seen.has(track.id)) {
        continue;
      }
      seen.add(track.id);
      out.push(track);
      if (out.length >= needed) {
        break;
      }
    }
    await sleep(80);
  }
  return out;
}

async function tryList(api, path, query) {
  try {
    const data = await api(path, { query });
    return extractSearchTracks(data);
  } catch {
    return [];
  }
}

function pickRoundRobin(buckets, target, seen) {
  const queues = buckets.map((bucket) => [...bucket]);
  const out = [];
  let added = true;
  while (out.length < target && added) {
    added = false;
    for (const queue of queues) {
      while (queue.length) {
        const track = queue.shift();
        if (!track || seen.has(track.id)) {
          continue;
        }
        seen.add(track.id);
        out.push(track);
        added = true;
        break;
      }
      if (out.length >= target) {
        break;
      }
    }
  }
  return out;
}

function scoreSimilar(seed, track) {
  let score = 1;
  if (seed.genreId && track.genreId && seed.genreId === track.genreId) {
    score += 4;
  }
  if (Number.isFinite(seed.bpm) && Number.isFinite(track.bpm) && seed.bpm > 0 && track.bpm > 0) {
    const delta = Math.abs(seed.bpm - track.bpm);
    if (delta <= 2) {
      score += 4;
    } else if (delta <= 6) {
      score += 3;
    } else if (delta <= 12) {
      score += 1;
    }
  }
  if (seed.keyId && track.keyId && seed.keyId === track.keyId) {
    score += 2;
  }
  const seedArtists = new Set((seed.artistIds || []).map(Number));
  if ((track.artistIds || []).some((id) => seedArtists.has(Number(id)))) {
    score += 1;
  }
  return score;
}

function extractSearchTracks(data) {
  if (!data || typeof data !== "object") {
    return [];
  }
  if (Array.isArray(data.results)) {
    return data.results;
  }
  if (Array.isArray(data.tracks?.results)) {
    return data.tracks.results;
  }
  if (Array.isArray(data.tracks)) {
    return data.tracks;
  }
  if (Array.isArray(data.items)) {
    return data.items;
  }
  if (Array.isArray(data)) {
    return data;
  }
  return [];
}

function normalizeImportedTrack(item) {
  const track = item?.track && typeof item.track === "object" ? item.track : item;
  const id = Number(track?.id);
  if (!Number.isFinite(id) || id <= 0) {
    return null;
  }
  return {
    id,
    title: track.name || track.title || "",
    mix: track.mix_name || track.mixName || "",
    artists: Array.isArray(track.artists)
      ? track.artists.map((artist) => artist?.name).filter(Boolean).join(", ")
      : "",
    url: `https://www.beatport.com/track/${track.slug || "track"}/${id}`,
  };
}

function enrichTrack(base, raw) {
  if (!base) {
    return null;
  }
  const track = raw?.track && typeof raw.track === "object" ? raw.track : raw || {};
  const genre = track.genre || (Array.isArray(track.genres) ? track.genres[0] : null);
  const key = track.key;
  const artists = Array.isArray(track.artists) ? track.artists : [];
  return {
    ...base,
    bpm: Number(track.bpm) || base.bpm || null,
    genreId: Number(genre?.id || track.genre_id || base.genreId) || null,
    keyId: Number(key?.id || track.key_id || base.keyId) || null,
    artistIds: artists.map((artist) => Number(artist?.id)).filter((id) => Number.isFinite(id) && id > 0),
  };
}

function pickMatch(source, results) {
  let best = null;
  let bestScore = 0;
  for (const candidate of results) {
    const titleScore = similarity(source.title, `${candidate.title} ${candidate.mix || ""}`);
    const artistScore = similarity(source.artists, candidate.artists);
    const score = titleScore * 0.7 + artistScore * 0.3;
    if (score > bestScore) {
      best = candidate;
      bestScore = score;
    }
  }
  if (!best) {
    return null;
  }
  const titleScore = similarity(source.title, `${best.title} ${best.mix || ""}`);
  if (titleScore < 0.22 || bestScore < 0.26) {
    return null;
  }
  return best;
}

function similarity(a, b) {
  const left = tokens(a);
  const right = tokens(b);
  if (!left.size || !right.size) {
    return 0;
  }
  let inter = 0;
  for (const token of left) {
    if (right.has(token)) {
      inter += 1;
    }
  }
  return inter / new Set([...left, ...right]).size;
}

function tokens(value) {
  return new Set(
    String(value || "")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .replace(
        /\b(feat|ft|featuring|with|vs|versus|and|the|a|an|original|mix|remix|extended|edit|radio|version|vip|remastered)\b/g,
        " "
      )
      .split(/\s+/)
      .filter((token) => token.length > 1)
  );
}

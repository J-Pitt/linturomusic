async function importExternalPlaylist(urlString, { api, sleep, onProgress = () => {} } = {}) {
  const source = parseExternalUrl(urlString);
  onProgress({ phase: "load", done: 0, total: 0, label: `Reading ${source.kind} playlist…` });

  const playlist = await loadExternalTracks(source);
  const incoming = playlist.tracks.slice(0, 250);
  if (!incoming.length) {
    throw new Error("No tracks found on that playlist. Check the URL and that it is public.");
  }

  const matched = [];
  const unmatched = [];
  const seen = new Set();

  for (let i = 0; i < incoming.length; i += 1) {
    const item = incoming[i];
    onProgress({
      phase: "match",
      done: i,
      total: incoming.length,
      label: `Matching ${i + 1}/${incoming.length}: ${item.title}`,
    });

    try {
      const hit = await matchBeatportTrack(item, api);
      if (hit && !seen.has(hit.id)) {
        seen.add(hit.id);
        matched.push(hit);
      } else if (!hit) {
        unmatched.push(item);
      }
    } catch {
      unmatched.push(item);
    }

    await sleep(110);
  }

  onProgress({
    phase: "done",
    done: incoming.length,
    total: incoming.length,
    label: `Matched ${matched.length} of ${incoming.length}`,
  });

  return {
    source: source.kind,
    title: playlist.title,
    matched,
    unmatched,
    total: incoming.length,
  };
}

function parseExternalUrl(raw) {
  const text = String(raw || "").trim();
  if (!text) {
    throw new Error("Paste a Spotify or SoundCloud playlist URL.");
  }

  let url;
  try {
    url = new URL(text);
  } catch {
    throw new Error("That does not look like a URL.");
  }

  const host = url.hostname.replace(/^www\./, "").toLowerCase();

  if (host === "open.spotify.com" || host === "play.spotify.com" || host === "spotify.link") {
    const path = url.pathname.replace(/^\/intl-[a-z]{2}(-[a-z]{2})?/i, "");
    const playlist = path.match(/\/playlist\/([A-Za-z0-9]+)/);
    if (playlist) {
      return { kind: "spotify", type: "playlist", id: playlist[1] };
    }
    const album = path.match(/\/album\/([A-Za-z0-9]+)/);
    if (album) {
      return { kind: "spotify", type: "album", id: album[1] };
    }
    const track = path.match(/\/track\/([A-Za-z0-9]+)/);
    if (track) {
      return { kind: "spotify", type: "track", id: track[1] };
    }
    throw new Error("Use a Spotify playlist, album, or track URL.");
  }

  if (host === "soundcloud.com" || host.endsWith(".soundcloud.com")) {
    return { kind: "soundcloud", type: url.pathname.includes("/sets/") ? "playlist" : "track", url: url.toString() };
  }

  throw new Error("Use a Spotify or SoundCloud playlist URL.");
}

async function loadExternalTracks(source) {
  if (source.kind === "spotify") {
    return loadSpotify(source);
  }
  return loadSoundCloud(source);
}

async function loadSpotify(source) {
  const token = await getSpotifyToken();
  const headers = { Authorization: `Bearer ${token}`, Accept: "application/json" };

  if (source.type === "track") {
    const track = await spotifyJson(`https://api.spotify.com/v1/tracks/${source.id}`, headers);
    return {
      title: track.name || "Spotify track",
      tracks: [spotifyTrack(track)].filter(Boolean),
    };
  }

  if (source.type === "album") {
    const album = await spotifyJson(`https://api.spotify.com/v1/albums/${source.id}`, headers);
    const tracks = [];
    let next = `https://api.spotify.com/v1/albums/${source.id}/tracks?limit=50`;
    while (next && tracks.length < 250) {
      const page = await spotifyJson(next, headers);
      for (const item of page.items || []) {
        tracks.push(spotifyTrack({ ...item, album }));
      }
      next = page.next;
    }
    return { title: album.name || "Spotify album", tracks: tracks.filter(Boolean) };
  }

  const playlist = await spotifyJson(`https://api.spotify.com/v1/playlists/${source.id}`, headers);
  const tracks = [];
  let next = `https://api.spotify.com/v1/playlists/${source.id}/tracks?limit=100`;
  while (next && tracks.length < 250) {
    const page = await spotifyJson(next, headers);
    for (const row of page.items || []) {
      tracks.push(spotifyTrack(row.track));
    }
    next = page.next;
  }
  return { title: playlist.name || "Spotify playlist", tracks: tracks.filter(Boolean) };
}

function spotifyTrack(track) {
  if (!track || track.is_local || !track.name) {
    return null;
  }
  const artists = Array.isArray(track.artists)
    ? track.artists.map((artist) => artist?.name).filter(Boolean).join(", ")
    : "";
  return {
    title: track.name,
    artists,
    url: track.external_urls?.spotify || "",
  };
}

async function getSpotifyToken() {
  const response = await fetch(
    "https://open.spotify.com/get_access_token?reason=transport&productType=web_player",
    { credentials: "include" }
  );
  if (!response.ok) {
    throw new Error("Log in to Spotify in Chrome, then try the import again.");
  }
  const data = await response.json();
  const token = data.accessToken || data.access_token;
  if (!token) {
    throw new Error("Log in to Spotify in Chrome, then try the import again.");
  }
  return token;
}

async function spotifyJson(url, headers) {
  const response = await fetch(url, { headers, credentials: "omit" });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401) {
      throw new Error("Spotify login expired. Open Spotify in Chrome and try again.");
    }
    throw new Error(data.error?.message || `Spotify request failed (${response.status}).`);
  }
  return data;
}

async function loadSoundCloud(source) {
  const clientId = await getSoundCloudClientId();
  const resolved = await soundCloudJson(
    `https://api-v2.soundcloud.com/resolve?url=${encodeURIComponent(source.url)}&client_id=${clientId}`
  );

  if (resolved.kind === "track") {
    return {
      title: resolved.title || "SoundCloud track",
      tracks: [soundCloudTrack(resolved)].filter(Boolean),
    };
  }

  if (resolved.kind !== "playlist") {
    throw new Error("Use a SoundCloud playlist (set) URL, or a single track.");
  }

  let tracks = (resolved.tracks || []).filter((track) => track && track.title);
  const missingIds = (resolved.tracks || [])
    .filter((track) => track?.id && !track.title)
    .map((track) => track.id);

  for (let i = 0; i < missingIds.length; i += 50) {
    const batch = missingIds.slice(i, i + 50);
    const extra = await soundCloudJson(
      `https://api-v2.soundcloud.com/tracks?ids=${batch.join(",")}&client_id=${clientId}`
    );
    const list = Array.isArray(extra) ? extra : extra.collection || [];
    tracks = tracks.concat(list);
  }

  return {
    title: resolved.title || "SoundCloud playlist",
    tracks: tracks.map(soundCloudTrack).filter(Boolean).slice(0, 250),
  };
}

function soundCloudTrack(track) {
  if (!track?.title) {
    return null;
  }
  return {
    title: track.title,
    artists: track.user?.username || track.publisher_metadata?.artist || "",
    url: track.permalink_url || "",
  };
}

async function getSoundCloudClientId() {
  const html = await fetch("https://soundcloud.com", { credentials: "include" }).then((res) => res.text());
  const inline = html.match(/client_id["']?\s*[:=]\s*["']([A-Za-z0-9]{16,})["']/);
  if (inline) {
    return inline[1];
  }

  const scripts = [...html.matchAll(/src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[^"]+\.js)"/g)].map(
    (match) => match[1]
  );
  for (const src of scripts.slice(0, 12)) {
    const js = await fetch(src).then((res) => res.text());
    const match = js.match(/client_id:"([A-Za-z0-9]{16,})"/) || js.match(/client_id=([A-Za-z0-9]{16,})/);
    if (match) {
      return match[1];
    }
  }

  throw new Error("Could not talk to SoundCloud. Open soundcloud.com once in Chrome, then try again.");
}

async function soundCloudJson(url) {
  const response = await fetch(url, { credentials: "omit" });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || `SoundCloud request failed (${response.status}).`);
  }
  return data;
}

async function matchBeatportTrack(source, api) {
  const query = `${source.artists || ""} ${source.title || ""}`.replace(/\s+/g, " ").trim().slice(0, 90);
  if (!query) {
    return null;
  }

  const data = await api("/catalog/search/", {
    query: { q: query, type: "tracks", per_page: 10, page: 1 },
  });
  const results = extractSearchTracks(data).map(normalizeImportedTrack).filter(Boolean);
  return pickMatch(source, results);
}

function extractSearchTracks(data) {
  if (!data || typeof data !== "object") {
    return [];
  }
  if (Array.isArray(data.results)) {
    return data.results;
  }
  if (Array.isArray(data.tracks?.results)) {
    return data.tracks.results;
  }
  if (Array.isArray(data.tracks)) {
    return data.tracks;
  }
  if (Array.isArray(data)) {
    return data;
  }
  return [];
}

function normalizeImportedTrack(item) {
  const track = item?.track && typeof item.track === "object" ? item.track : item;
  const id = Number(track?.id);
  if (!Number.isFinite(id) || id <= 0) {
    return null;
  }
  return {
    id,
    title: track.name || track.title || "",
    mix: track.mix_name || track.mixName || "",
    artists: Array.isArray(track.artists)
      ? track.artists.map((artist) => artist?.name).filter(Boolean).join(", ")
      : "",
    url: `https://www.beatport.com/track/${track.slug || "track"}/${id}`,
  };
}

function pickMatch(source, results) {
  let best = null;
  let bestScore = 0;
  for (const candidate of results) {
    const titleScore = similarity(source.title, `${candidate.title} ${candidate.mix || ""}`);
    const artistScore = similarity(source.artists, candidate.artists);
    const score = titleScore * 0.7 + artistScore * 0.3;
    if (score > bestScore) {
      best = candidate;
      bestScore = score;
    }
  }
  if (!best) {
    return null;
  }
  const titleScore = similarity(source.title, `${best.title} ${best.mix || ""}`);
  if (titleScore < 0.22 || bestScore < 0.26) {
    return null;
  }
  return best;
}

function similarity(a, b) {
  const left = tokens(a);
  const right = tokens(b);
  if (!left.size || !right.size) {
    return 0;
  }
  let inter = 0;
  for (const token of left) {
    if (right.has(token)) {
      inter += 1;
    }
  }
  return inter / new Set([...left, ...right]).size;
}

function tokens(value) {
  return new Set(
    String(value || "")
      .toLowerCase()
      .replace(/[^\p{L}\p{N}\s]/gu, " ")
      .replace(
        /\b(feat|ft|featuring|with|vs|versus|and|the|a|an|original|mix|remix|extended|edit|radio|version|vip|remastered)\b/g,
        " "
      )
      .split(/\s+/)
      .filter((token) => token.length > 1)
  );
}

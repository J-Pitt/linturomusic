(() => {
  const SCRIPT_VERSION = "1.4.1";
  const HOST_ID = "bp-add-to-playlist-host";
  const LAST_PLAYLIST_KEY = "lastPlaylistId";
  const TRACK_LINK = /\/track\/([^/?#]+)\/(\d+)/i;

  const STYLE = `
    :host {
      all: initial;
    }
    * {
      box-sizing: border-box;
      font-family: Inter, "Helvetica Neue", Arial, sans-serif;
    }
    .overlay {
      position: fixed;
      inset: 0;
      z-index: 2147483646;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
      background: rgba(0, 0, 0, 0.72);
    }
    .modal {
      width: min(560px, 100%);
      max-height: min(88vh, 820px);
      display: flex;
      flex-direction: column;
      background: #141414;
      color: #ffffff;
      border: 1px solid #343434;
      border-radius: 16px;
      box-shadow: 0 24px 80px rgba(0, 0, 0, 0.55);
      overflow: hidden;
    }
    header {
      display: flex;
      align-items: flex-start;
      justify-content: space-between;
      gap: 16px;
      padding: 20px 20px 16px;
      border-bottom: 1px solid #2d2d2d;
    }
    header h1 {
      margin: 0 0 4px;
      font-size: 18px;
      font-weight: 600;
      letter-spacing: 0.01em;
    }
    header p,
    .hint,
    .status,
    .empty {
      margin: 0;
      color: #b8b8b8;
      font-size: 13px;
      line-height: 1.45;
    }
    .close {
      appearance: none;
      border: 0;
      background: #2d2d2d;
      color: #ffffff;
      width: 32px;
      height: 32px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 18px;
      line-height: 1;
    }
    .close:hover {
      background: #3d3d3d;
    }
    .body {
      padding: 16px 20px 20px;
      overflow: auto;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    .tracks {
      background: #1d1d1d;
      border: 1px solid #2d2d2d;
      border-radius: 12px;
      padding: 12px;
      max-height: 180px;
      overflow: auto;
    }
    .track {
      display: flex;
      gap: 8px;
      padding: 6px 0;
      font-size: 13px;
      line-height: 1.35;
    }
    .track + .track {
      border-top: 1px solid #2a2a2a;
    }
    .track-title {
      color: #ffffff;
    }
    .track-meta {
      color: #9c9c9c;
    }
    label {
      display: block;
      margin-bottom: 6px;
      color: #d4d4d4;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }
    input[type="file"] {
      width: 100%;
      color: #d4d4d4;
      font-size: 12px;
    }
    input[type="search"],
    input[type="text"],
    select {
      width: 100%;
      height: 40px;
      padding: 0 12px;
      border: 1px solid #343434;
      border-radius: 8px;
      background: #262626;
      color: #ffffff;
      outline: none;
    }
    input:focus,
    select:focus {
      border-color: #01ff95;
      box-shadow: 0 0 0 3px rgba(1, 255, 149, 0.16);
    }
    .playlists {
      display: flex;
      flex-direction: column;
      gap: 6px;
      max-height: 220px;
      overflow: auto;
      padding-right: 2px;
    }
    .playlist {
      display: flex;
      align-items: center;
      gap: 10px;
      width: 100%;
      padding: 10px 12px;
      border: 1px solid #2d2d2d;
      border-radius: 10px;
      background: #1d1d1d;
      color: inherit;
      text-align: left;
      cursor: pointer;
    }
    .playlist:hover {
      border-color: #5a5a5a;
    }
    .playlist.selected {
      border-color: #01ff95;
      background: rgba(1, 255, 149, 0.08);
    }
    .playlist strong {
      display: block;
      font-size: 14px;
      font-weight: 600;
    }
    .playlist span {
      color: #9c9c9c;
      font-size: 12px;
    }
    .row {
      display: flex;
      gap: 8px;
    }
    .row input {
      flex: 1;
    }
    button.primary,
    button.secondary {
      appearance: none;
      border: 0;
      border-radius: 8px;
      height: 40px;
      padding: 0 14px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
    }
    button.primary {
      background: #01ff95;
      color: #141414;
    }
    button.primary:hover:not(:disabled) {
      background: #01cc77;
    }
    button.secondary {
      background: #2d2d2d;
      color: #ffffff;
    }
    button.secondary:hover:not(:disabled) {
      background: #3d3d3d;
    }
    button:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
    [hidden] {
      display: none !important;
    }
    footer {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      padding-top: 4px;
    }
    .import {
      display: flex;
      flex-direction: column;
      gap: 8px;
      padding: 12px;
      border: 1px solid #2d2d2d;
      border-radius: 12px;
      background: #1d1d1d;
    }
    .progress {
      height: 6px;
      border-radius: 999px;
      background: #2d2d2d;
      overflow: hidden;
    }
    .progress > div {
      height: 100%;
      width: 0%;
      background: #01ff95;
      transition: width 180ms ease;
    }
    .error {
      color: #ff8a8a;
      font-size: 13px;
      margin: 0;
    }
    .success {
      color: #01ff95;
      font-size: 13px;
      margin: 0;
    }
  `;

  let host = null;
  let shadow = null;
  let state = createState();

  if (!window.__bpAddToPlaylistListenerBound) {
    window.__bpAddToPlaylistListenerBound = true;
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === "OPEN_MODAL") {
        window.__bpOpenAddToPlaylistModal?.();
        sendResponse({ ok: true });
      }
      return false;
    });
  }

  function createState() {
    return {
      tracks: [],
      playlists: [],
      filteredPlaylists: [],
      selectedPlaylistId: null,
      userPickedPlaylist: false,
      query: "",
      newName: "",
      visibleCount: 0,
      listTotal: 0,
      loading: false,
      adding: false,
      error: "",
      result: "",
      progress: 0,
      added: 0,
      skipped: 0,
      failed: 0,
      folderName: "",
      seeds: [],
      importing: false,
      unmatched: [],
    };
  }

  async function openModal() {
    ensureHost();
    window.removeEventListener("keydown", onKeyDown);
    window.addEventListener("keydown", onKeyDown);
    state = createState();
    render();
    await refresh();
  }

  function closeModal() {
    window.removeEventListener("keydown", onKeyDown);
    host?.remove();
    host = null;
    shadow = null;
  }

  function ensureHost() {
    if (host?.isConnected) {
      return;
    }
    host = document.getElementById(HOST_ID) || document.createElement("div");
    host.id = HOST_ID;
    document.documentElement.appendChild(host);
    shadow = host.attachShadow({ mode: "open" });
  }

  async function refresh() {
    state.loading = true;
    state.error = "";
    state.result = "";
    render();

    try {
      const pageInfo = collectPageInfo();
      state.visibleCount = pageInfo.visibleCount;
      state.listTotal = pageInfo.listTotal;
      const [apiResult, stored, playlistsResult] = await Promise.allSettled([
        send({
          type: "FETCH_PAGE_TRACKS",
          url: location.href,
          next: pageInfo.next,
        }),
        chrome.storage.local.get(LAST_PLAYLIST_KEY),
        send({ type: "GET_PLAYLISTS" }),
      ]);

      const apiTracks = apiResult.status === "fulfilled" ? apiResult.value.tracks || [] : [];
      state.tracks = mergeTracks(pageInfo.tracks, apiTracks);
      if (pageInfo.listTotal > state.listTotal) {
        state.listTotal = pageInfo.listTotal;
      }
      if (state.tracks.length > state.listTotal) {
        state.listTotal = state.tracks.length;
      }

      if (playlistsResult.status === "fulfilled") {
        state.playlists = (playlistsResult.value.playlists || []).map((playlist) => ({
          ...playlist,
          id: Number(playlist.id),
        }));
        filterPlaylists();
        const lastId = Number(
          stored.status === "fulfilled" ? stored.value[LAST_PLAYLIST_KEY] : NaN
        );
        if (!state.userPickedPlaylist) {
          state.selectedPlaylistId = state.playlists.some((playlist) => playlist.id === lastId)
            ? lastId
            : null;
        }
      } else {
        state.error = playlistsResult.reason?.message || "Could not load playlists.";
      }

      if (!state.tracks.length && apiResult.status === "rejected") {
        state.error = state.error || apiResult.reason?.message || "No tracks found on this page.";
      }
    } catch (error) {
      state.error = error.message || String(error);
    } finally {
      state.loading = false;
      render();
    }
  }

  function collectPageInfo() {
    const domTracks = tracksFromDom();
    const nextData = readNextData();
    const queryTracks = tracksFromNextData(nextData);
    const pagination = findTrackPagination(nextData);
    const tracks = mergeTracks(domTracks, queryTracks, pagination.tracks);
    return {
      tracks,
      visibleCount: domTracks.length || tracks.length,
      listTotal: Math.max(pagination.count, visibleTotalFromDom(), tracks.length),
      next: pagination.next,
    };
  }

  function readNextData() {
    const script = document.getElementById("__NEXT_DATA__");
    if (!script?.textContent) {
      return null;
    }
    try {
      return JSON.parse(script.textContent);
    } catch {
      return null;
    }
  }

  function visibleTotalFromDom() {
    const text = document.body?.innerText || "";
    const match =
      text.match(/showing\s+\d+\s*[–-]\s*\d+\s+of\s+(\d+)/i) ||
      text.match(/of\s+(\d{2,5})\s+(tracks|results)/i);
    return match ? Number(match[1]) : 0;
  }

  function tracksFromDom() {
    const tracks = new Map();

    document.querySelectorAll('a[href*="/track/"]').forEach((anchor) => {
      const match = String(anchor.getAttribute("href") || "").match(TRACK_LINK);
      if (!match) {
        return;
      }

      const id = Number(match[2]);
      const row = anchor.closest(
        '[data-testid="tracks-table-row"], [data-testid*="track-row"], [class*="TracksList"], tr, li'
      );
      const title =
        textOf(row?.querySelector('[data-testid="marquee-parent"]')) ||
        textOf(anchor) ||
        decodeURIComponent(match[1].replace(/-/g, " "));
      const artists =
        textOf(row?.querySelector('[data-testid*="artist"], [class*="Artist"], [class*="artist"]')) || "";

      if (!tracks.has(id)) {
        tracks.set(id, {
          id,
          title,
          mix: "",
          artists,
          url: `https://www.beatport.com/track/${match[1]}/${id}`,
        });
      }
    });

    return [...tracks.values()];
  }

  function tracksFromNextData(data) {
    if (!data) {
      return [];
    }

    const found = new Map();
    const queries = data?.props?.pageProps?.dehydratedState?.queries || [];
    queries.forEach((query) => {
      extractResultArrays(query?.state?.data).forEach((item) => {
        const track = asTrack(item);
        if (track) {
          found.set(track.id, track);
        }
      });
    });
    return [...found.values()];
  }

  function extractResultArrays(payload) {
    if (!payload) {
      return [];
    }
    if (Array.isArray(payload)) {
      return payload;
    }
    const buckets = [payload.results, payload.tracks?.results, payload.tracks, payload.items];
    return buckets.find((bucket) => Array.isArray(bucket)) || [];
  }

  function findTrackPagination(data) {
    const empty = { tracks: [], count: 0, next: null };
    if (!data) {
      return empty;
    }

    let best = empty;
    const queries = data?.props?.pageProps?.dehydratedState?.queries || [];
    queries.forEach((query) => {
      const payload = query?.state?.data;
      if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
        return;
      }
      const results = extractResultArrays(payload)
        .map(asTrack)
        .filter(Boolean);
      if (!results.length) {
        return;
      }
      const count = Number(payload.count || payload.total || 0);
      const next = typeof payload.next === "string" ? payload.next : payload.tracks?.next || null;
      if (count > best.count || results.length > best.tracks.length) {
        best = { tracks: results, count, next };
      }
    });
    return best;
  }

  function asTrack(node) {
    if (!node || typeof node !== "object" || Array.isArray(node)) {
      return null;
    }

    const source = node.track && typeof node.track === "object" ? node.track : node;
    const id = Number(source.id || node.track_id);
    if (!Number.isFinite(id) || id <= 0) {
      return null;
    }

    const looksLikeTrack =
      source.mix_name != null ||
      source.mixName != null ||
      (Array.isArray(source.artists) && source.bpm != null);

    if (!looksLikeTrack) {
      return null;
    }

    return {
      id,
      title: source.name || source.title || "",
      mix: source.mix_name || source.mixName || "",
      artists: Array.isArray(source.artists)
        ? source.artists.map((artist) => artist?.name).filter(Boolean).join(", ")
        : "",
      url: `https://www.beatport.com/track/${source.slug || "track"}/${id}`,
    };
  }

  function mergeTracks(...lists) {
    const tracks = new Map();
    lists.flat().forEach((track) => {
      if (!track?.id) {
        return;
      }
      const existing = tracks.get(track.id);
      tracks.set(track.id, {
        id: track.id,
        title: track.title || existing?.title || `Track ${track.id}`,
        mix: track.mix || existing?.mix || "",
        artists: track.artists || existing?.artists || "",
        url: track.url || existing?.url || `https://www.beatport.com/track/track/${track.id}`,
      });
    });
    return [...tracks.values()];
  }

  function textOf(node) {
    return node?.textContent?.replace(/\s+/g, " ").trim() || "";
  }

  function send(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (response?.error) {
          reject(new Error(response.error));
          return;
        }
        resolve(response || {});
      });
    });
  }

  function render() {
    if (!shadow) {
      return;
    }

    const selected = state.playlists.find((playlist) => Number(playlist.id) === Number(state.selectedPlaylistId));
    const playlistOptions = [...state.filteredPlaylists];
    if (selected && !playlistOptions.some((playlist) => Number(playlist.id) === Number(selected.id))) {
      playlistOptions.unshift(selected);
    }
    const canAdd = Boolean(selected && state.tracks.length && !state.adding && !state.loading && !state.importing);
    const foundLabel = state.importing
      ? state.result || "Finding similar tracks on Beatport…"
      : state.loading
      ? "Scanning this Beatport page…"
      : state.unmatched.length
        ? `${state.tracks.length} similar · ${state.unmatched.length} seed${state.unmatched.length === 1 ? "" : "s"} not on Beatport`
        : state.visibleCount && state.tracks.length > state.visibleCount
        ? `${state.tracks.length} tracks found. This page only shows ${state.visibleCount}.`
        : `${state.tracks.length} track${state.tracks.length === 1 ? "" : "s"} found`;
    const addLabel = selected
      ? `Add ${state.tracks.length} track${state.tracks.length === 1 ? "" : "s"} to ${selected.name}`
      : "Choose a playlist first";

    shadow.innerHTML = `
      <style>${STYLE}</style>
      <div class="overlay" id="overlay">
        <div class="modal" role="dialog" aria-modal="true" aria-labelledby="bp-modal-title">
          <header>
            <div>
              <h1 id="bp-modal-title">Add to Beatport playlist</h1>
              <p>${escapeHtml(foundLabel)}</p>
            </div>
            <button class="close" id="close" aria-label="Close">×</button>
          </header>
          <div class="body">
            <div class="tracks">
              ${
                state.tracks.length
                  ? state.tracks
                      .slice(0, 12)
                      .map(
                        (track) => `
                          <div class="track">
                            <div>
                              <div class="track-title">${escapeHtml(formatTitle(track))}</div>
                              <div class="track-meta">${escapeHtml(track.artists || "Unknown artist")}</div>
                            </div>
                          </div>`
                      )
                      .join("") +
                    (state.tracks.length > 12
                      ? `<p class="hint">And ${state.tracks.length - 12} more…</p>`
                      : "")
                  : `<p class="empty">${
                      state.loading
                        ? "Looking for tracks…"
                        : "No tracks found yet. Wait for the list to finish loading, refresh, or pick a folder of songs to find similar Beatport tracks."
                    }</p>`
              }
            </div>

            <div class="import">
              <label for="folder-input">Folder of songs</label>
              <div class="row">
                <input id="folder-input" type="file" webkitdirectory multiple accept="audio/*,.mp3,.wav,.aiff,.aif,.flac,.m4a,.aac,.ogg" ${state.adding || state.importing ? "disabled" : ""} />
                <button class="secondary" id="similar" ${state.adding || state.importing || !state.seeds.length ? "disabled" : ""}>Find similar</button>
              </div>
              <p class="hint">${
                state.seeds.length
                  ? `${state.seeds.length} file${state.seeds.length === 1 ? "" : "s"} from ${escapeHtml(state.folderName || "folder")}. Builds ~100 similar Beatport tracks (catalog match, not fingerprint).`
                  : "Choose a folder. Filenames like Artist - Title.mp3 work best."
              }</p>
            </div>

            <div>
              <label for="playlist-search">Choose playlist</label>
              <input id="playlist-search" type="search" placeholder="Search your playlists" value="${escapeAttr(state.query)}" ${state.loading ? "disabled" : ""} />
            </div>
            <select id="playlist-select" ${state.loading || state.adding ? "disabled" : ""}>
              <option value="" ${state.selectedPlaylistId ? "" : "selected"}>Choose a playlist…</option>
              ${playlistOptions
                .map(
                  (playlist) => `
                    <option value="${playlist.id}" ${Number(playlist.id) === Number(state.selectedPlaylistId) ? "selected" : ""}>
                      ${escapeHtml(playlist.name)} (${playlist.trackCount})
                    </option>`
                )
                .join("")}
            </select>

            <div>
              <label for="new-playlist">Or create a playlist</label>
              <div class="row">
                <input id="new-playlist" type="text" maxlength="64" placeholder="New playlist name" value="${escapeAttr(state.newName)}" ${state.loading || state.adding ? "disabled" : ""} />
                <button class="secondary" id="create" ${state.loading || state.adding || !state.newName.trim() ? "disabled" : ""}>Create</button>
              </div>
            </div>

            <p class="hint" ${state.unmatched.length ? "" : "hidden"}>Seeds not on Beatport: ${escapeHtml(
              state.unmatched
                .slice(0, 6)
                .map((track) => track.title)
                .join(", ")
            )}${state.unmatched.length > 6 ? ` +${state.unmatched.length - 6} more` : ""}</p>
            <p class="error" id="error-status" ${state.error ? "" : "hidden"}>${escapeHtml(state.error)}</p>
            <p class="success" id="live-status" ${state.result ? "" : "hidden"}>${escapeHtml(state.result)}</p>
            <div class="progress" id="progress-wrap" ${state.adding || state.importing ? "" : "hidden"}>
              <div id="progress-bar" style="width:${state.progress}%"></div>
            </div>

            <footer>
              <button class="secondary" id="refresh" ${state.loading || state.adding || state.importing ? "disabled" : ""}>Refresh tracks</button>
              <button class="primary" id="add" ${canAdd ? "" : "disabled"}>
                ${state.adding ? `Adding ${state.added + state.skipped + state.failed}/${state.tracks.length}…` : escapeHtml(addLabel)}
              </button>
            </footer>
          </div>
        </div>
      </div>
    `;

    shadow.getElementById("overlay").addEventListener("click", (event) => {
      if (event.target.id === "overlay") {
        closeModal();
      }
    });
    shadow.getElementById("close").addEventListener("click", closeModal);
    shadow.getElementById("refresh").addEventListener("click", () => refresh());
    shadow.getElementById("create").addEventListener("click", () => createPlaylist());
    shadow.getElementById("add").addEventListener("click", () => addTracks());
    shadow.getElementById("similar").addEventListener("click", () => findSimilar());
    shadow.getElementById("folder-input").addEventListener("change", (event) => {
      readFolder(event.target.files);
    });

    const search = shadow.getElementById("playlist-search");
    search.addEventListener("input", (event) => {
      state.query = event.target.value;
      filterPlaylists();
      renderPreserve(["playlist-search", "new-playlist", "playlist-select"]);
    });

    const newPlaylist = shadow.getElementById("new-playlist");
    newPlaylist.addEventListener("input", (event) => {
      state.newName = event.target.value;
      const create = shadow.getElementById("create");
      if (create) {
        create.disabled = state.loading || state.adding || !state.newName.trim();
      }
    });
    newPlaylist.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        createPlaylist();
      }
    });

    shadow.getElementById("playlist-select").addEventListener("change", (event) => {
      choosePlaylist(event.target.value);
      renderPreserve(["playlist-search", "new-playlist", "playlist-select"]);
    });

  }

  function renderPreserve(ids) {
    const values = {};
    const focused = shadow.activeElement?.id;
    ids.forEach((id) => {
      const node = shadow.getElementById(id);
      if (node) {
        values[id] = { value: node.value, start: node.selectionStart, end: node.selectionEnd };
      }
    });
    render();
    ids.forEach((id) => {
      const node = shadow.getElementById(id);
      const saved = values[id];
      if (node && saved) {
        node.value = saved.value;
        if (focused === id) {
          node.focus();
          try {
            node.setSelectionRange(saved.start, saved.end);
          } catch {
            // Ignore inputs that do not support selection ranges.
          }
        }
      }
    });
  }

  function choosePlaylist(id) {
    const playlistId = Number(id);
    state.userPickedPlaylist = true;
    if (!id || !Number.isFinite(playlistId) || playlistId <= 0) {
      state.selectedPlaylistId = null;
      chrome.storage.local.remove(LAST_PLAYLIST_KEY);
      return;
    }
    state.selectedPlaylistId = playlistId;
    chrome.storage.local.set({ [LAST_PLAYLIST_KEY]: playlistId });
  }

  function filterPlaylists() {
    const query = state.query.trim().toLowerCase();
    state.filteredPlaylists = query
      ? state.playlists.filter((playlist) => playlist.name.toLowerCase().includes(query))
      : state.playlists;
  }

  async function readFolder(fileList) {
    const files = [...(fileList || [])];
    const parsed = await parseAudioFiles(files);
    state.seeds = parsed.seeds;
    state.folderName = parsed.folderName;
    state.error = parsed.seeds.length ? "" : "No audio files in that folder.";
    render();
  }

  function findSimilar() {
    if (!state.seeds.length || state.importing || state.adding) {
      return;
    }

    state.importing = true;
    state.progress = 0;
    state.error = "";
    state.result = "Matching your folder on Beatport…";
    state.unmatched = [];
    render();

    const port = chrome.runtime.connect({ name: "similar-folder" });
    port.onMessage.addListener((message) => {
      if (message?.type === "PROGRESS") {
        state.result = message.label || state.result;
        if (message.total) {
          state.progress = Math.round((Number(message.done || 0) / message.total) * 100);
        }
        updateAddingStatus();
        return;
      }

      if (message?.type === "DONE") {
        state.importing = false;
        state.progress = 100;
        if (message.error) {
          state.error = message.error;
        } else {
          state.tracks = message.similar || [];
          state.unmatched = message.unmatched || [];
          state.visibleCount = state.tracks.length;
          if (!state.newName.trim() && message.playlistName) {
            state.newName = message.playlistName;
          }
          state.result = `Found ${state.tracks.length} similar tracks from ${message.totalSeeds || state.seeds.length} files in ${
            message.title || state.folderName || "your folder"
          }. Create or choose a playlist, then add them.`;
        }
        render();
        try {
          port.disconnect();
        } catch {
          // Already disconnected.
        }
      }
    });
    port.onDisconnect.addListener(() => {
      if (state.importing) {
        state.importing = false;
        state.error =
          chrome.runtime.lastError?.message || "Search stopped before it finished. Click Find similar again.";
        render();
      }
    });
    port.postMessage({
      type: "SIMILAR",
      folderName: state.folderName,
      seeds: state.seeds.map((seed) => ({ title: seed.title, artists: seed.artists, file: seed.file })),
    });
  }

  async function createPlaylist() {
    const name = state.newName.trim();
    if (!name || state.adding) {
      return;
    }

    state.loading = true;
    state.error = "";
    state.result = "";
    render();

    try {
      const { playlist } = await send({ type: "CREATE_PLAYLIST", name });
      const created = { ...playlist, id: Number(playlist.id) };
      state.playlists = [created, ...state.playlists.filter((item) => Number(item.id) !== created.id)]
        .sort((a, b) => a.name.localeCompare(b.name));
      choosePlaylist(created.id);
      state.newName = "";
      state.query = "";
      filterPlaylists();
      state.result = `Created “${created.name}”. Select a different playlist above if that is not the destination.`;
    } catch (error) {
      state.error = error.message || String(error);
    } finally {
      state.loading = false;
      render();
    }
  }

  function addTracks() {
    const select = shadow?.getElementById("playlist-select");
    choosePlaylist(select?.value || "");
    if (!state.selectedPlaylistId || !state.tracks.length || state.adding) {
      return;
    }

    state.adding = true;
    state.progress = 0;
    state.added = 0;
    state.skipped = 0;
    state.failed = 0;
    state.error = "";
    state.result = "Starting…";
    render();

    const port = chrome.runtime.connect({ name: "add-tracks" });
    port.onMessage.addListener((message) => {
      if (message?.type === "PROGRESS") {
        state.added = message.added || 0;
        state.skipped = message.skipped || 0;
        state.failed = message.failed || 0;
        state.progress = message.progress || 0;
        state.result = `Added ${state.added} · skipped ${state.skipped} · failed ${state.failed} of ${message.total}`;
        updateAddingStatus();
        return;
      }

      if (message?.type === "DONE") {
        finishAdd(message);
        try {
          port.disconnect();
        } catch {
          // Already disconnected.
        }
      }
    });
    port.onDisconnect.addListener(() => {
      if (state.adding) {
        finishAdd({
          error: chrome.runtime.lastError?.message || "The add stopped before it finished. Click Add again to continue.",
          added: state.added,
          skipped: state.skipped,
          failed: state.failed,
          total: state.tracks.length,
        });
      }
    });
    port.postMessage({
      type: "ADD_TRACKS",
      playlistId: state.selectedPlaylistId,
      trackIds: state.tracks.map((track) => track.id),
    });
  }

  function finishAdd(result) {
    if (!state.adding) {
      return;
    }
    state.adding = false;
    state.progress = 100;
    const playlist = state.playlists.find((item) => item.id === state.selectedPlaylistId);
    if (result.error && !result.total) {
      state.error = result.error;
    } else {
      const parts = [`Added ${result.added || 0}`];
      if (result.skipped) {
        parts.push(`${result.skipped} already in playlist`);
      }
      if (result.failed) {
        parts.push(`${result.failed} failed`);
      }
      state.result = `${parts.join(", ")} of ${result.total || state.tracks.length} in ${playlist?.name || "the playlist"}.`;
      if (result.failed) {
        state.error = friendlyAddError(result.errors?.[0] || result.error);
      } else {
        state.error = "";
      }
      if (playlist) {
        playlist.trackCount += result.added || 0;
      }
    }
    render();
  }

  function updateAddingStatus() {
    if (!shadow) {
      return;
    }
    const live = shadow.getElementById("live-status");
    const error = shadow.getElementById("error-status");
    const bar = shadow.getElementById("progress-bar");
    const wrap = shadow.getElementById("progress-wrap");
    const add = shadow.getElementById("add");
    if (live) {
      live.hidden = !state.result;
      live.textContent = state.result;
    }
    if (error) {
      error.hidden = !state.error;
      error.textContent = state.error;
    }
    if (wrap) {
      wrap.hidden = !(state.adding || state.importing);
    }
    if (bar) {
      bar.style.width = `${state.progress}%`;
    }
    if (add) {
      const selected = state.playlists.find((playlist) => Number(playlist.id) === Number(state.selectedPlaylistId));
      add.textContent = state.adding
        ? `Adding ${state.added + state.skipped + state.failed}/${state.tracks.length}…`
        : selected
          ? `Add ${state.tracks.length} track${state.tracks.length === 1 ? "" : "s"} to ${selected.name}`
          : `Add ${state.tracks.length || ""} track${state.tracks.length === 1 ? "" : "s"}`;
    }
  }

  function onKeyDown(event) {
    if (event.key === "Escape" && host?.isConnected) {
      closeModal();
    }
  }

  function friendlyAddError(message) {
    const text = String(message || "");
    if (/401|credentials were not provided|unauthorized/i.test(text)) {
      return "Beatport dropped the session on one request. Click Add again if any tracks are missing.";
    }
    return text;
  }

  function formatTitle(track) {
    return track.mix && !track.title.toLowerCase().includes(track.mix.toLowerCase())
      ? `${track.title} (${track.mix})`
      : track.title;
  }

  const AUDIO_EXT = /\.(mp3|wav|aiff?|flac|m4a|aac|ogg|wma)$/i;

  async function parseAudioFiles(files) {
    const audio = files.filter((file) => {
      const name = file.name || "";
      if (!name || name.startsWith(".")) {
        return false;
      }
      return AUDIO_EXT.test(name) || String(file.type || "").startsWith("audio/");
    });

    let folderName = "";
    const seeds = [];
    for (const file of audio.slice(0, 40)) {
      if (!folderName) {
        const relative = file.webkitRelativePath || file.name;
        folderName = relative.split("/")[0] || "crate";
      }
      const fromTags = await readAudioTags(file);
      const fromName = parseFilename(file.name);
      seeds.push({
        title: fromTags.title || fromName.title,
        artists: fromTags.artists || fromName.artists,
        file: file.name,
      });
    }

    return { folderName, seeds: seeds.filter((seed) => seed.title) };
  }

  function parseFilename(filename) {
    const name = String(filename || "")
      .replace(AUDIO_EXT, "")
      .replace(/^\d+[\s.\-_]+/, "")
      .trim();
    const parts = name.split(/\s[-–—]\s/);
    if (parts.length >= 2) {
      return { artists: parts[0].trim(), title: parts.slice(1).join(" - ").trim() };
    }
    return { artists: "", title: name.replace(/[_]+/g, " ").trim() };
  }

  async function readAudioTags(file) {
    try {
      const buf = await file.slice(0, 256 * 1024).arrayBuffer();
      return parseId3(new Uint8Array(buf));
    } catch {
      return { title: "", artists: "" };
    }
  }

  function parseId3(bytes) {
    if (bytes.length < 10 || bytes[0] !== 0x49 || bytes[1] !== 0x44 || bytes[2] !== 0x54) {
      return { title: "", artists: "" };
    }
    const version = bytes[3];
    const size = ((bytes[6] & 0x7f) << 21) | ((bytes[7] & 0x7f) << 14) | ((bytes[8] & 0x7f) << 7) | (bytes[9] & 0x7f);
    const end = Math.min(bytes.length, 10 + size);
    let offset = 10;
    if (bytes[5] & 0x40) {
      if (end - offset < 4) {
        return { title: "", artists: "" };
      }
      const extSize =
        version === 4
          ? ((bytes[offset] & 0x7f) << 21) |
            ((bytes[offset + 1] & 0x7f) << 14) |
            ((bytes[offset + 2] & 0x7f) << 7) |
            (bytes[offset + 3] & 0x7f)
          : (bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];
      offset += Math.max(4, extSize);
    }

    let title = "";
    let artists = "";
    while (offset + 10 <= end) {
      const id = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]);
      if (!/^[A-Z0-9]{4}$/.test(id)) {
        break;
      }
      const frameSize =
        version === 4
          ? ((bytes[offset + 4] & 0x7f) << 21) |
            ((bytes[offset + 5] & 0x7f) << 14) |
            ((bytes[offset + 6] & 0x7f) << 7) |
            (bytes[offset + 7] & 0x7f)
          : (bytes[offset + 4] << 24) | (bytes[offset + 5] << 16) | (bytes[offset + 6] << 8) | bytes[offset + 7];
      offset += 10;
      if (frameSize <= 0 || offset + frameSize > bytes.length) {
        break;
      }
      const payload = bytes.slice(offset, offset + frameSize);
      offset += frameSize;
      if (id === "TIT2") {
        title = decodeId3Text(payload);
      } else if (id === "TPE1") {
        artists = decodeId3Text(payload).split("/")[0].trim();
      }
    }
    return { title, artists };
  }

  function decodeId3Text(payload) {
    if (!payload.length) {
      return "";
    }
    const encoding = payload[0];
    const body = payload.slice(1);
    try {
      if (encoding === 0) {
        return new TextDecoder("latin1").decode(body).replace(/\0+$/g, "").trim();
      }
      if (encoding === 3) {
        return new TextDecoder("utf-8").decode(body).replace(/\0+$/g, "").trim();
      }
      const utf16 = encoding === 1 || encoding === 2;
      if (utf16) {
        return new TextDecoder("utf-16").decode(body).replace(/\0+$/g, "").trim();
      }
    } catch {
      return "";
    }
    return "";
  }

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function escapeAttr(value) {
    return escapeHtml(value);
  }

  window.__bpOpenAddToPlaylistModal = openModal;
  window.__bpAddToPlaylistVersion = SCRIPT_VERSION;
})();

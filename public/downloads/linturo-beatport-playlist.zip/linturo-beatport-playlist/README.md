# Beatport Add Page to Playlist

Chrome extension that opens a modal on Beatport and adds every track on the current page to one of your playlists.

## Install

1. Open Chrome and go to `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Choose this `beatport-add-to-playlist` folder

## Use

1. Log in to [Beatport](https://www.beatport.com)
2. Open a page with tracks (chart, top 100, release, genre, playlist, search results)
3. Click the extension icon
4. Pick an existing playlist or create a new one
5. Click **Add tracks**

The extension uses your existing Beatport session. It does not store your password.

## How it finds tracks

It combines:

- Track links already rendered on the page
- Data embedded in Beatport’s `__NEXT_DATA__`
- Beatport’s playlist/catalog API when the URL is a known list page

If the list is still loading, use **Refresh tracks**.

## Share this private repo

The GitHub repo is private. Other people cannot see it unless you invite them.

To share it with specific people (an allowlist):

1. Open the repo on GitHub
2. Go to **Settings → Collaborators**
3. Click **Add people** and invite their GitHub username or email

They get an email invite. After they accept, they can clone the repo and load the unpacked extension in Chrome. You can remove access from the same Collaborators page.

You can also send someone a zip of this folder without giving them GitHub access. That copy will not get updates unless you send a new zip.

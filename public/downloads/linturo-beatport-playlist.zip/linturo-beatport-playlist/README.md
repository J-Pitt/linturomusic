# Beatport Add Page to Playlist

Chrome extension that adds Beatport tracks to one of your playlists. It can take every track on the current Beatport page, or seed **similar** Beatport tracks from a **folder of audio files** or a **pasted list of track names**.

## Install

1. Open Chrome and go to `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Choose this `beatport-add-to-playlist` folder

## Use

1. Log in to [Beatport](https://www.beatport.com)
2. Open a Beatport page and click the extension icon
3. Pick an existing playlist or create a new one
4. Click **Add tracks** for the current page

### Similar crate from a folder or track names

1. On Beatport, open the extension
2. Either:
   - Choose a folder of songs (`Artist - Title.mp3` filenames work best; ID3 tags are used when present), or
   - Paste track names (one per line, `Artist - Title` preferred)
3. Set how many similar tracks to pull (1–250)
4. Click **Find similar** — it matches those seeds on Beatport, then searches related / same-genre / nearby-BPM tracks
5. Create or pick a playlist and add the results

This is catalog matching, not audio fingerprinting. Tracks the catalog cannot identify stay listed as unmatched. Similar tracks exclude the seeds themselves.

The extension uses your existing Beatport session. It does not store your password.

## How it finds tracks on a Beatport page

It combines:

- Track links already rendered on the page
- Data embedded in Beatport’s `__NEXT_DATA__`
- Beatport’s playlist/catalog API when the URL is a known list page

If the list is still loading, use **Refresh tracks**.

## Share this private repo

The GitHub repo is private. Other people cannot see it unless you invite them.

To share it with specific people (an allowlist):

1. Open the repo on GitHub
2. Go to **Settings → Collaborators**
3. Click **Add people** and invite their GitHub username or email

They get an email invite. After they accept, they can clone the repo and load the unpacked extension in Chrome. You can remove access from the same Collaborators page.

You can also send someone a zip of this folder without giving them GitHub access. That copy will not get updates unless you send a new zip.

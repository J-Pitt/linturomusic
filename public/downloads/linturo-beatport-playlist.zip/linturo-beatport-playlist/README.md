# Beatport Add Page to Playlist

Chrome extension that adds Beatport tracks to one of your playlists. It can take every track on the current Beatport page, or import a **Spotify** / **SoundCloud** playlist and match what it can on Beatport.

## Install

1. Open Chrome and go to `chrome://extensions`
2. Turn on **Developer mode**
3. Click **Load unpacked**
4. Choose this `beatport-add-to-playlist` folder

## Use

1. Log in to [Beatport](https://www.beatport.com)
2. Open a Beatport page and click the extension icon
3. Pick an existing playlist or create a new one
4. Click **Add tracks** for the current page

### Import Spotify or SoundCloud

1. Stay logged in to Spotify or SoundCloud in Chrome
2. On Beatport, open the extension
3. Paste a playlist URL (Spotify playlist/album, or SoundCloud set)
4. Click **Match** — it searches Beatport for each track
5. Choose a Beatport playlist and add the matches

Tracks it cannot find stay listed as unmatched. Matching is best-effort (title + artist).

The extension uses your existing Beatport session. It does not store your password.

## How it finds tracks on a Beatport page

It combines:

- Track links already rendered on the page
- Data embedded in Beatport’s `__NEXT_DATA__`
- Beatport’s playlist/catalog API when the URL is a known list page

If the list is still loading, use **Refresh tracks**.

## Share this private repo

The GitHub repo is private. Other people cannot see it unless you invite them.

To share it with specific people (an allowlist):

1. Open the repo on GitHub
2. Go to **Settings → Collaborators**
3. Click **Add people** and invite their GitHub username or email

They get an email invite. After they accept, they can clone the repo and load the unpacked extension in Chrome. You can remove access from the same Collaborators page.

You can also send someone a zip of this folder without giving them GitHub access. That copy will not get updates unless you send a new zip.

importScripts("import-playlist.js");

const API_BASE = "https://api.beatport.com/v4";
const SESSION_URL = "https://www.beatport.com/api/auth/session";
const LOCALE_PREFIX = /^\/(de|fr|es|it|ja|pt|nl)(?=\/)/;

let cachedToken = null;
let cachedTokenAt = 0;

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id || !tab.url) {
    return;
  }

  if (!/^https:\/\/www\.beatport\.com\//.test(tab.url)) {
    await notify(
      "Open a Beatport page first",
      "Go to a Beatport track list, chart, release, or playlist, then click the extension."
    );
    return;
  }

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["content.js"],
  });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      if (typeof window.__bpOpenAddToPlaylistModal === "function") {
        window.__bpOpenAddToPlaylistModal();
      }
    },
  });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  handleMessage(message)
    .then(sendResponse)
    .catch((error) => sendResponse({ error: error.message || String(error) }));
  return true;
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "import-playlist") {
    port.onMessage.addListener(async (message) => {
      if (message?.type !== "IMPORT") {
        return;
      }
      try {
        const result = await importExternalPlaylist(message.url, {
          api,
          sleep,
          onProgress: (progress) => {
            try {
              port.postMessage({ type: "PROGRESS", ...progress });
            } catch {
              // Modal closed.
            }
          },
        });
        port.postMessage({ type: "DONE", ...result });
      } catch (error) {
        port.postMessage({ type: "DONE", error: error.message || String(error) });
      }
    });
    return;
  }

  if (port.name !== "add-tracks") {
    return;
  }

  port.onMessage.addListener(async (message) => {
    if (message?.type !== "ADD_TRACKS") {
      return;
    }

    try {
      const result = await addTracksToPlaylist(
        message.playlistId,
        message.trackIds,
        (progress) => {
          try {
            port.postMessage({ type: "PROGRESS", ...progress });
          } catch {
            // The modal may have closed; keep adding anyway.
          }
        }
      );
      port.postMessage({ type: "DONE", ...result });
    } catch (error) {
      port.postMessage({ type: "DONE", error: error.message || String(error) });
    }
  });
});

async function handleMessage(message) {
  switch (message.type) {
    case "GET_PLAYLISTS":
      return { playlists: await fetchAllPlaylists() };
    case "CREATE_PLAYLIST":
      return { playlist: await createPlaylist(message.name) };
    case "FETCH_PAGE_TRACKS":
      return {
        tracks: await fetchTracksForPage(message.url, {
          next: message.next,
        }),
      };
    case "ADD_TRACKS":
      return addTracksToPlaylist(message.playlistId, message.trackIds);
    case "IMPORT_EXTERNAL_PLAYLIST":
      return importExternalPlaylist(message.url, { api, sleep });
    default:
      throw new Error(`Unknown message: ${message.type}`);
  }
}

async function getAccessToken(force = false) {
  if (!force && cachedToken && Date.now() - cachedTokenAt < 8 * 60 * 1000) {
    return cachedToken;
  }

  const response = await fetch(SESSION_URL, { credentials: "include" });
  if (!response.ok) {
    throw new Error("Could not read your Beatport session. Refresh the page and try again.");
  }

  const session = await response.json();
  const token =
    session?.token?.accessToken ||
    session?.token?.access_token ||
    session?.accessToken;

  if (!token) {
    throw new Error("Log in to Beatport in this browser, then click the extension again.");
  }

  cachedToken = token;
  cachedTokenAt = Date.now();
  return token;
}

async function api(path, { method = "GET", query, body } = {}, retried = false) {
  const token = await getAccessToken(retried);
  const url = new URL(resolveApiUrl(path));

  if (query && Object.keys(query).length) {
    for (const [key, value] of Object.entries(query)) {
      if (value != null && value !== "") {
        url.searchParams.set(key, String(value));
      }
    }
  }

  let response;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    response = await fetch(url.toString(), {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        ...(body ? { "Content-Type": "application/json" } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (response.status !== 429) {
      break;
    }
    await sleep(800 * (attempt + 1));
  }

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { raw: text };
    }
  }

  if (response.status === 401 && !retried) {
    cachedToken = null;
    cachedTokenAt = 0;
    return api(path, { method, query, body }, true);
  }

  if (!response.ok) {
    const detail =
      data?.detail ||
      data?.error ||
      data?.message ||
      (typeof data?.raw === "string" ? data.raw.slice(0, 180) : "") ||
      response.statusText;
    const error = new Error(`${method} ${url.pathname} failed (${response.status}): ${detail}`);
    error.status = response.status;
    error.detail = String(detail || "");
    throw error;
  }

  return data;
}

async function fetchAllPlaylists() {
  const playlists = [];

  for (let page = 1; page <= 20; page += 1) {
    const data = await api("/my/playlists/", {
      query: { page, per_page: 100 },
    });
    const batch = Array.isArray(data) ? data : data?.results || [];
    playlists.push(
      ...batch.map((playlist) => ({
        id: playlist.id,
        name: playlist.name,
        trackCount: playlist.track_count ?? playlist.trackCount ?? 0,
        isPublic: Boolean(playlist.is_public),
      }))
    );
    if (batch.length < 100 || !data?.next) {
      break;
    }
  }

  return playlists.sort((a, b) => a.name.localeCompare(b.name));
}

async function createPlaylist(name) {
  const trimmed = String(name || "").trim();
  if (!trimmed) {
    throw new Error("Enter a playlist name.");
  }

  const playlist = await api("/my/playlists/", {
    method: "POST",
    body: { name: trimmed },
  });

  return {
    id: playlist.id,
    name: playlist.name,
    trackCount: playlist.track_count ?? 0,
    isPublic: Boolean(playlist.is_public),
  };
}

function resolveApiUrl(path) {
  if (!path) {
    throw new Error("Missing API path");
  }
  if (/^https?:\/\//i.test(path)) {
    return path.replace("https://api-internal.beatportprod.com", "https://api.beatport.com");
  }
  if (path.startsWith("/v4/")) {
    return `https://api.beatport.com${path}`;
  }
  if (path.startsWith("/")) {
    return `${API_BASE}${path}`;
  }
  return `${API_BASE}/${path}`;
}

async function firstWorking(loaders) {
  for (const loader of loaders) {
    try {
      const items = await loader();
      if (items?.length) {
        return items;
      }
    } catch {
      // Try the next endpoint. Beatport list URLs vary by page type.
    }
  }
  return [];
}

async function fetchPaginated(path, query = {}, maxPages = 80) {
  const items = [];
  let nextPath = path;
  let nextQuery = { per_page: 100, page: 1, ...query };
  let total = Number.POSITIVE_INFINITY;

  for (let page = 1; page <= maxPages; page += 1) {
    const data = await api(nextPath, { query: nextQuery });
    const batch = extractResultArray(data);
    items.push(...batch);

    const counted = Number(data?.count);
    if (Number.isFinite(counted) && counted > 0) {
      total = counted;
    }

    if (typeof data?.next === "string" && data.next) {
      nextPath = data.next;
      nextQuery = {};
      if (items.length >= total) {
        break;
      }
      continue;
    }

    if (batch.length === 0 || items.length >= total) {
      break;
    }

    nextPath = path;
    nextQuery = { per_page: 100, ...query, page: page + 1 };
  }

  return items;
}

async function fetchFromNext(nextUrl, maxPages = 80) {
  return fetchPaginated(nextUrl, {}, maxPages);
}

function extractResultArray(data) {
  if (Array.isArray(data)) {
    return data;
  }
  if (!data || typeof data !== "object") {
    return [];
  }
  if (Array.isArray(data.results)) {
    return data.results;
  }
  if (Array.isArray(data.tracks)) {
    return data.tracks;
  }
  if (Array.isArray(data.items)) {
    return data.items;
  }
  if (data.tracks && Array.isArray(data.tracks.results)) {
    return data.tracks.results;
  }
  return [];
}

function pagePath(urlString) {
  const url = new URL(urlString);
  return url.pathname.replace(LOCALE_PREFIX, "") || "/";
}

function parsePage(urlString) {
  const url = new URL(urlString);
  const path = pagePath(urlString);
  const query = url.searchParams.get("q") || url.searchParams.get("query") || "";
  let match;

  if ((match = path.match(/^\/library\/playlists\/(\d+)/))) {
    return { type: "my-playlist", id: match[1] };
  }
  if ((match = path.match(/^\/release\/[^/]+\/(\d+)/))) {
    return { type: "release", id: match[1] };
  }
  if ((match = path.match(/^\/chart\/[^/]+\/(\d+)/))) {
    return { type: "chart", id: match[1] };
  }
  if ((match = path.match(/^\/genre\/[^/]+\/(\d+)\/top-100\/?$/))) {
    return { type: "genre-top", id: match[1] };
  }
  if ((match = path.match(/^\/genre\/[^/]+\/(\d+)(?:\/tracks)?\/?$/))) {
    return { type: "genre-tracks", id: match[1] };
  }
  if (path === "/top-100" || path.startsWith("/top-100/")) {
    return { type: "top-100" };
  }
  if ((match = path.match(/^\/artist\/[^/]+\/(\d+)/))) {
    return { type: "artist", id: match[1] };
  }
  if ((match = path.match(/^\/label\/[^/]+\/(\d+)/))) {
    return { type: "label", id: match[1] };
  }
  if ((match = path.match(/^\/track\/[^/]+\/(\d+)/))) {
    return { type: "track", id: match[1] };
  }
  if (path.startsWith("/search") || query) {
    return { type: "search", q: query };
  }
  return { type: "unknown" };
}

function normalizeTrack(item) {
  if (!item || typeof item !== "object") {
    return null;
  }

  const track = item.track && typeof item.track === "object" ? item.track : item;
  const id = Number(track.id || item.track_id || item.trackId);
  if (!Number.isFinite(id) || id <= 0) {
    return null;
  }

  const artists = Array.isArray(track.artists)
    ? track.artists.map((artist) => artist?.name).filter(Boolean).join(", ")
    : "";
  const title = track.name || track.title || "";
  const mix = track.mix_name || track.mixName || "";
  const slug = track.slug || "track";

  return {
    id,
    title,
    mix,
    artists,
    url: `https://www.beatport.com/track/${slug}/${id}`,
  };
}

async function fetchTracksForPage(urlString, extras = {}) {
  const page = parsePage(urlString);
  const items = [];

  const collected = await firstWorking((() => {
    switch (page.type) {
      case "my-playlist":
        return [
          () => fetchPaginated(`/my/playlists/${page.id}/tracks/`),
          () => fetchPaginated(`/catalog/playlists/${page.id}/tracks/`),
        ];
      case "release":
        return [
          () => fetchPaginated(`/catalog/releases/${page.id}/tracks/`),
          async () => {
            const release = await api(`/catalog/releases/${page.id}/`);
            return extractResultArray(release.tracks || release);
          },
        ];
      case "chart":
        return [
          () => fetchPaginated(`/catalog/charts/${page.id}/tracks/`),
          async () => {
            const chart = await api(`/catalog/charts/${page.id}/`);
            return extractResultArray(chart.tracks || chart);
          },
        ];
      case "genre-top":
        return [() => fetchPaginated(`/catalog/tracks/top/${page.id}/`, { per_page: 100 })];
      case "genre-tracks":
        return [
          () => fetchPaginated("/catalog/tracks/", { genre_id: page.id, order_by: "-publish_date" }),
          () => fetchPaginated(`/catalog/tracks/top/${page.id}/`, { per_page: 100 }),
        ];
      case "top-100":
        return [() => fetchPaginated("/catalog/tracks/top/", { per_page: 100 })];
      case "artist":
        return [
          () => fetchPaginated("/catalog/tracks/", { artist_id: page.id, order_by: "-publish_date" }),
          () => fetchPaginated(`/catalog/artists/${page.id}/tracks/`),
          () => fetchPaginated(`/catalog/artists/${page.id}/top/`),
        ];
      case "label":
        return [
          () => fetchPaginated("/catalog/tracks/", { label_id: page.id, order_by: "-publish_date" }),
          () => fetchPaginated(`/catalog/labels/${page.id}/tracks/`),
          () => fetchPaginated(`/catalog/labels/${page.id}/top/`),
        ];
      case "search":
        return [() => fetchPaginated("/catalog/search/", { q: page.q, type: "tracks" })];
      case "track":
        return [async () => [await api(`/catalog/tracks/${page.id}/`)]];
      default:
        return [];
    }
  })());

  items.push(...collected);

  if (extras.next) {
    try {
      items.push(...(await fetchFromNext(extras.next)));
    } catch {
      // Visible-page tracks are still useful if remaining pages fail.
    }
  }

  const tracks = [];
  const seen = new Set();
  for (const item of items) {
    const track = normalizeTrack(item);
    if (!track || seen.has(track.id)) {
      continue;
    }
    seen.add(track.id);
    tracks.push(track);
  }
  return tracks;
}

async function fetchPlaylistTrackIds(playlistId) {
  const items = await fetchPaginated(`/my/playlists/${playlistId}/tracks/`);
  return new Set(
    items
      .map((item) => Number(item.track_id || item.trackId || item.track?.id))
      .filter((id) => Number.isFinite(id) && id > 0)
  );
}

function isDuplicateError(error) {
  const text = `${error?.message || ""} ${error?.detail || ""}`.toLowerCase();
  return (
    error?.status === 409 ||
    text.includes("already") ||
    text.includes("duplicate") ||
    text.includes("exist")
  );
}

async function addTracksToPlaylist(playlistId, trackIds, onProgress = () => {}) {
  const uniqueIds = [...new Set((trackIds || []).map(Number).filter((id) => Number.isFinite(id) && id > 0))];
  if (!playlistId) {
    throw new Error("Choose a playlist first.");
  }
  if (uniqueIds.length === 0) {
    throw new Error("No tracks to add.");
  }

  let existing = new Set();
  try {
    existing = await fetchPlaylistTrackIds(playlistId);
  } catch {
    existing = new Set();
  }

  let added = 0;
  let skipped = 0;
  let failed = 0;
  const errors = [];
  const total = uniqueIds.length;

  const report = () => {
    onProgress({
      added,
      skipped,
      failed,
      total,
      progress: Math.round(((added + skipped + failed) / total) * 100),
    });
  };
  report();

  for (const trackId of uniqueIds) {
    if (existing.has(trackId)) {
      skipped += 1;
      report();
      continue;
    }

    try {
      await api(`/my/playlists/${playlistId}/tracks/`, {
        method: "POST",
        body: { track_id: trackId },
      });
      added += 1;
      existing.add(trackId);
    } catch (error) {
      if (isDuplicateError(error)) {
        skipped += 1;
        existing.add(trackId);
      } else {
        failed += 1;
        if (errors.length < 8) {
          errors.push(error.message || String(error));
        }
      }
    }

    report();
    await sleep(90);
  }

  return {
    added,
    skipped,
    failed,
    total,
    errors,
  };
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function notify(title, message) {
  try {
    await chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title,
      message,
    });
  } catch {
    // Notifications are optional.
  }
}
